import DriveView from "@/components/DriveView";

export default function DriveRootPage() {
  return <DriveView folderId={null} />;
}
